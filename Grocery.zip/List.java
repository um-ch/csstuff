import java.util.ArrayList;

public class List {

	public static void main(String[] args) {
		
		Food flour = new Food("Flour", 2, "Pounds");
		
		Medicine advil = new Medicine("Advil", 1, "Package");
	
		ArrayList<Product> groceries = new ArrayList<>();
			groceries.add(flour);
			groceries.add(advil);
			
		
	for (int i = 0; i < 2; i++) {
		
		System.out.println(groceries.get(i).quantity + " " + groceries.get(i).measurementType + " of " + groceries.get(i).item);
		
		}
	}
}
