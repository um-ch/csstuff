public class Food extends Product {
	
	public Food(String item, int quantity, String measurementType) {
		
		super(item, quantity, measurementType);
		
	}
	
	}