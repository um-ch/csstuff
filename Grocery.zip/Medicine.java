public class Medicine extends Product {
	
	public Medicine(String item, int quantity, String measurementType) {
		
		super(item, quantity, measurementType);
		
		}
	}
