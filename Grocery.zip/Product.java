public class Product {

	public String item;
	public int quantity;
	public String measurementType;
	
		public Product(String item, int quantity, String measurementType) {
		
			this.item = item;
			this.quantity = quantity;
			this.measurementType = measurementType;
		
	}

}
